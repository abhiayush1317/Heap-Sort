"""Small reusable widgets: tooltip, statistic card, legend."""
import tkinter as tk

import customtkinter as ctk

from gui import theme


class Tooltip:
    def __init__(self, widget, text: str):
        self.widget, self.text, self.tip = widget, text, None
        widget.bind("<Enter>", self._show, add="+")
        widget.bind("<Leave>", self._hide, add="+")

    def _show(self, _event=None):
        if self.tip:
            return
        x = self.widget.winfo_rootx() + 12
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry(f"+{x}+{y}")
        tk.Label(self.tip, text=self.text, bg="#2d3748", fg="white", padx=8, pady=4,
                 font=(theme.FONT, 9), justify="left", wraplength=260).pack()

    def _hide(self, _event=None):
        if self.tip:
            self.tip.destroy()
            self.tip = None


class StatCard(ctk.CTkFrame):
    def __init__(self, master, title: str, value: str = "-"):
        super().__init__(master, fg_color=theme.CARD, corner_radius=10)
        ctk.CTkLabel(self, text=title, font=(theme.FONT, 11), text_color=theme.MUTED).pack(
            anchor="w", padx=12, pady=(8, 0))
        self.value = ctk.CTkLabel(self, text=value, font=(theme.FONT, 18, "bold"),
                                  text_color=theme.TEXT, anchor="w")
        self.value.pack(anchor="w", padx=12, pady=(0, 8), fill="x")

    def set(self, text) -> None:
        self.value.configure(text=str(text))


def make_legend(master) -> ctk.CTkFrame:
    frame = ctk.CTkFrame(master, fg_color="transparent")
    for i, (name, color) in enumerate(theme.LEGEND):
        row = ctk.CTkFrame(frame, fg_color="transparent")
        row.grid(row=i // 2, column=i % 2, sticky="w", padx=2, pady=1)
        ctk.CTkLabel(row, text="", width=12, height=12, fg_color=color, corner_radius=3).pack(side="left")
        ctk.CTkLabel(row, text=name, font=(theme.FONT, 11), text_color=theme.MUTED).pack(side="left", padx=4)
    return frame
