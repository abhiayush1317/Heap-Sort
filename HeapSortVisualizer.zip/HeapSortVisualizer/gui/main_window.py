"""Main application window: sidebar + Dashboard / Visualizer / Learn / Compare pages."""
import threading
import tkinter as tk

import customtkinter as ctk

from algorithms.comparison import COMPLEXITY, benchmark
from algorithms.heap_sort import analyze
from gui import theme
from gui.components import StatCard, Tooltip, make_legend
from gui.visualization import BarView, TreeView
from utils.content import LEARN_TOPICS
from utils.helpers import MAX_ELEMENTS, format_array, parse_input, random_array


# =============================================================== Dashboard
class DashboardPage(ctk.CTkFrame):
    def __init__(self, master, go_visualizer):
        super().__init__(master, fg_color="transparent")
        ctk.CTkLabel(self, text="Heap Sort Visualizer", font=(theme.FONT, 32, "bold"),
                     text_color=theme.TEXT).pack(anchor="w", padx=30, pady=(30, 0))
        ctk.CTkLabel(self, text="Interactive Sorting Algorithm Learning System",
                     font=(theme.FONT, 15), text_color=theme.MUTED).pack(anchor="w", padx=30, pady=(0, 20))
        grid = ctk.CTkFrame(self, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        cards = [
            ("Visualize", "Watch the array as bars and as a binary tree while the Max Heap is built "
                          "and elements are extracted one by one."),
            ("Control", "Start, pause, resume, reset, change speed, or step forward / backward "
                        "through every recorded operation."),
            ("Learn", "Read short explanations of heaps, heapify, index formulas and complexity."),
            ("Compare", "Benchmark Heap Sort against five other algorithms on the same input."),
        ]
        for i, (title, body) in enumerate(cards):
            card = ctk.CTkFrame(grid, fg_color=theme.CARD, corner_radius=12)
            card.grid(row=i // 2, column=i % 2, sticky="nsew", padx=6, pady=6)
            grid.grid_columnconfigure(i % 2, weight=1)
            ctk.CTkLabel(card, text=title, font=(theme.FONT, 16, "bold"), text_color=theme.ACCENT).pack(
                anchor="w", padx=16, pady=(14, 2))
            ctk.CTkLabel(card, text=body, font=(theme.FONT, 12), text_color=theme.TEXT, wraplength=380,
                         justify="left").pack(anchor="w", padx=16, pady=(0, 14))
        facts = ctk.CTkFrame(self, fg_color=theme.PANEL, corner_radius=12)
        facts.pack(fill="x", padx=30, pady=16)
        ctk.CTkLabel(facts, justify="left", font=(theme.FONT, 13), text_color=theme.TEXT, text=(
            "Heap Sort at a glance\n"
            "   Time:  O(n log n) in best, average and worst case\n"
            "   Extra space:  O(1)  (in place)        Stable:  No\n"
            "   Idea:  build a Max Heap, then repeatedly move the root to the end of the array"
        )).pack(anchor="w", padx=16, pady=14)
        ctk.CTkButton(self, text="Open Visualizer  >", height=40, font=(theme.FONT, 14, "bold"),
                      command=go_visualizer).pack(anchor="w", padx=30, pady=6)


# ============================================================== Visualizer
class VisualizerPage(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color="transparent")
        self.result = None
        self.steps = []
        self.pos = 0
        self.playing = False
        self._job = None
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self._build_controls()
        self._build_main()
        self.generate_random()

    # ---------------------------------------------------------- layout
    def _build_controls(self):
        p = ctk.CTkScrollableFrame(self, width=250, fg_color=theme.PANEL, corner_radius=12)
        p.grid(row=0, column=0, sticky="ns", padx=(0, 10))

        def heading(text):
            ctk.CTkLabel(p, text=text, font=(theme.FONT, 13, "bold"), text_color=theme.ACCENT).pack(
                anchor="w", padx=6, pady=(12, 4))

        def button(text, cmd, tip, **kw):
            b = ctk.CTkButton(p, text=text, command=cmd, height=32, **kw)
            Tooltip(b, tip)
            return b

        heading("INPUT")
        self.entry = ctk.CTkEntry(p, placeholder_text="e.g. 45, 12, 78, -3, 9")
        self.entry.pack(fill="x", padx=6)
        self.entry.bind("<Return>", lambda _e: self.apply_custom())
        Tooltip(self.entry, f"Numbers separated by commas (max {MAX_ELEMENTS}). Negatives, "
                            "duplicates and decimals are allowed.")
        button("Use Custom Numbers", self.apply_custom, "Load the numbers typed above").pack(fill="x", padx=6, pady=4)
        self.error = ctk.CTkLabel(p, text="", text_color=theme.ERROR, wraplength=220, justify="left",
                                  font=(theme.FONT, 11))
        self.error.pack(anchor="w", padx=6)

        self.size_label = ctk.CTkLabel(p, text="Elements: 10", font=(theme.FONT, 12))
        self.size_label.pack(anchor="w", padx=6, pady=(6, 0))
        self.size = ctk.CTkSlider(p, from_=1, to=MAX_ELEMENTS, number_of_steps=MAX_ELEMENTS - 1,
                                  command=lambda v: self.size_label.configure(text=f"Elements: {int(v)}"))
        self.size.set(10)
        self.size.pack(fill="x", padx=6)
        button("Generate New Array", self.generate_random, "Create a new random array of the chosen size",
               fg_color="#4f46e5", hover_color="#4338ca").pack(fill="x", padx=6, pady=6)

        heading("SORTING CONTROLS")
        self.btn_start = button("Start Sorting", self.start, "Play the animation from the beginning",
                                fg_color="#16a34a", hover_color="#15803d")
        self.btn_start.pack(fill="x", padx=6, pady=2)
        row = ctk.CTkFrame(p, fg_color="transparent")
        row.pack(fill="x", padx=6, pady=2)
        row.grid_columnconfigure((0, 1), weight=1)
        self.btn_pause = ctk.CTkButton(row, text="Pause", command=self.pause, height=32, fg_color="#d97706",
                                       hover_color="#b45309")
        self.btn_pause.grid(row=0, column=0, sticky="ew", padx=(0, 3))
        self.btn_resume = ctk.CTkButton(row, text="Resume", command=self.resume, height=32)
        self.btn_resume.grid(row=0, column=1, sticky="ew", padx=(3, 0))
        row2 = ctk.CTkFrame(p, fg_color="transparent")
        row2.pack(fill="x", padx=6, pady=2)
        row2.grid_columnconfigure((0, 1), weight=1)
        b1 = ctk.CTkButton(row2, text="< Step Back", command=self.step_back, height=32, fg_color="#475569",
                           hover_color="#334155")
        b1.grid(row=0, column=0, sticky="ew", padx=(0, 3))
        b2 = ctk.CTkButton(row2, text="Step Fwd >", command=self.step_forward, height=32, fg_color="#475569",
                           hover_color="#334155")
        b2.grid(row=0, column=1, sticky="ew", padx=(3, 0))
        Tooltip(b1, "Go back one recorded operation")
        Tooltip(b2, "Advance one recorded operation (pauses playback)")
        button("Reset", self.reset, "Stop and return to the original array",
               fg_color="#dc2626", hover_color="#b91c1c").pack(fill="x", padx=6, pady=2)

        self.speed_label = ctk.CTkLabel(p, text="Speed: 60", font=(theme.FONT, 12))
        self.speed_label.pack(anchor="w", padx=6, pady=(10, 0))
        self.speed = ctk.CTkSlider(p, from_=1, to=100, number_of_steps=99,
                                   command=lambda v: self.speed_label.configure(text=f"Speed: {int(v)}"))
        self.speed.set(60)
        self.speed.pack(fill="x", padx=6)
        Tooltip(self.speed, "Higher = faster. Takes effect immediately, also while playing.")

        heading("COLOR LEGEND")
        make_legend(p).pack(anchor="w", padx=6)

    def _build_main(self):
        m = ctk.CTkFrame(self, fg_color="transparent")
        m.grid(row=0, column=1, sticky="nsew")
        m.grid_columnconfigure(0, weight=1)
        m.grid_rowconfigure(2, weight=1)

        cards = ctk.CTkFrame(m, fg_color="transparent")
        cards.grid(row=0, column=0, sticky="ew")
        self.cards = {}
        for i, name in enumerate(["Operation", "Step", "Comparisons", "Swaps", "Heap size", "Exec. time"]):
            cards.grid_columnconfigure(i, weight=1, uniform="c")
            c = StatCard(cards, name)
            c.grid(row=0, column=i, sticky="ew", padx=3, pady=3)
            self.cards[name] = c
        Tooltip(self.cards["Exec. time"], "Measured on a separate, non-animated run of Heap Sort. "
                                          "It varies between runs and machines.")

        self.message = ctk.CTkLabel(m, text="", anchor="w", font=(theme.FONT, 13, "bold"),
                                    text_color=theme.TEXT, fg_color=theme.CARD, corner_radius=8, height=34)
        self.message.grid(row=1, column=0, sticky="ew", padx=3, pady=4)

        views = ctk.CTkFrame(m, fg_color="transparent")
        views.grid(row=2, column=0, sticky="nsew")
        views.grid_columnconfigure(0, weight=1)
        views.grid_rowconfigure((0, 1), weight=1, uniform="v")
        self.bars = BarView(views, height=180)
        self.bars.grid(row=0, column=0, sticky="nsew", padx=3, pady=(0, 4))
        self.tree = TreeView(views, height=240)
        self.tree.grid(row=1, column=0, sticky="nsew", padx=3)

        info = ctk.CTkFrame(m, fg_color=theme.CARD, corner_radius=10)
        info.grid(row=3, column=0, sticky="ew", padx=3, pady=(4, 0))
        self.lbl_orig = self._info_row(info, "Original array")
        self.lbl_cur = self._info_row(info, "Current array")
        self.lbl_final = self._info_row(info, "Final sorted array")

    @staticmethod
    def _info_row(parent, title):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=10, pady=2)
        ctk.CTkLabel(row, text=title, width=130, anchor="w", font=(theme.FONT, 11, "bold"),
                     text_color=theme.MUTED).pack(side="left", anchor="n")
        lbl = ctk.CTkLabel(row, text="", anchor="w", justify="left", wraplength=700, font=(theme.MONO, 12))
        lbl.pack(side="left", fill="x", expand=True)
        return lbl

    # ------------------------------------------------------- data loading
    def _load(self, data):
        self._stop()
        self.error.configure(text="")
        self.result = analyze(data)         # records steps + timing (pure computation, very fast)
        self.steps = self.result.steps
        self.pos = 0
        self.lbl_orig.configure(text=format_array(data))
        self._show()

    def apply_custom(self):
        try:
            data = parse_input(self.entry.get())
        except ValueError as exc:
            self.error.configure(text=f"Invalid input: {exc}")
            return
        self.size.set(max(1, len(data)))
        self.size_label.configure(text=f"Elements: {len(data)}")
        self._load(data)

    def generate_random(self):
        try:
            data = random_array(int(self.size.get()))
        except ValueError as exc:
            self.error.configure(text=str(exc))
            return
        self.entry.delete(0, "end")
        self.entry.insert(0, ", ".join(map(str, data)))
        self._load(data)

    # ------------------------------------------------------------ playback
    def _delay(self) -> int:
        return int(1000 - self.speed.get() * 9.6)       # speed 100 -> ~40 ms, speed 1 -> ~990 ms

    def _stop(self):
        self.playing = False
        if self._job is not None:
            self.after_cancel(self._job)
            self._job = None

    def _tick(self):
        self._job = None
        if not self.playing:
            return
        if self.pos < len(self.steps) - 1:
            self.pos += 1
            self._show()
        if self.pos >= len(self.steps) - 1:
            self.playing = False
            return
        self._job = self.after(self._delay(), self._tick)

    def start(self):
        if not self.steps:
            return
        self._stop()
        self.pos = 0
        self._show()
        self.playing = True
        self._job = self.after(self._delay(), self._tick)

    def pause(self):
        self._stop()

    def resume(self):
        if self.playing or self.pos >= len(self.steps) - 1:
            return
        self.playing = True
        self._job = self.after(self._delay(), self._tick)

    def reset(self):
        self._stop()
        self.pos = 0
        self._show()

    def step_forward(self):
        self._stop()
        if self.pos < len(self.steps) - 1:
            self.pos += 1
            self._show()

    def step_back(self):
        self._stop()
        if self.pos > 0:
            self.pos -= 1
            self._show()

    # ------------------------------------------------------------- display
    def _show(self):
        if not self.steps:
            return
        s = self.steps[self.pos]
        last = len(self.steps) - 1
        self.bars.draw(s)
        self.tree.draw(s)
        names = {"init": "Start", "build": "Build heap", "build_done": "Heap ready",
                 "extract": "Extract max", "done": "Finished"}
        self.cards["Operation"].set(names.get(s.phase, s.phase))
        self.cards["Step"].set(f"{self.pos} / {last}")
        self.cards["Comparisons"].set(s.comparisons)
        self.cards["Swaps"].set(s.swaps)
        self.cards["Heap size"].set(s.heap_size)
        self.cards["Exec. time"].set(f"{self.result.time_ms:.3f} ms")
        self.message.configure(text="  " + s.message)
        self.lbl_cur.configure(text=format_array(s.array))
        self.lbl_final.configure(text=format_array(self.result.sorted_array) if self.pos == last
                                 else "(shown when sorting finishes)")

    def destroy(self):
        self._stop()
        super().destroy()


# ================================================================== Learn
class LearnPage(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color="transparent")
        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True)
        self._fill(scroll)

    @staticmethod
    def _fill(self):
        ctk.CTkLabel(self, text="DSA Learning", font=(theme.FONT, 26, "bold")).pack(anchor="w", padx=10, pady=(6, 10))
        for title, body in LEARN_TOPICS:
            card = ctk.CTkFrame(self, fg_color=theme.CARD, corner_radius=10)
            card.pack(fill="x", padx=8, pady=5)
            ctk.CTkLabel(card, text=title, font=(theme.FONT, 15, "bold"), text_color=theme.ACCENT).pack(
                anchor="w", padx=14, pady=(10, 2))
            ctk.CTkLabel(card, text=body, justify="left", wraplength=780, font=(theme.FONT, 13),
                         text_color=theme.TEXT).pack(anchor="w", padx=14, pady=(0, 12))


# ================================================================ Compare
class ComparePage(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color="transparent")
        self._result = None
        ctk.CTkLabel(self, text="Algorithm Comparison", font=(theme.FONT, 26, "bold")).pack(
            anchor="w", padx=10, pady=(6, 6))

        ctk.CTkLabel(self, text="Theoretical complexity", font=(theme.FONT, 14, "bold"),
                     text_color=theme.ACCENT).pack(anchor="w", padx=10)
        lines = [f"{'Algorithm':<16}{'Best':<13}{'Average':<13}{'Worst':<13}{'Aux. space'}"]
        lines += [f"{n:<16}{b:<13}{a:<13}{w:<13}{s}" for n, b, a, w, s in COMPLEXITY]
        t = ctk.CTkTextbox(self, height=170, font=(theme.MONO, 13), fg_color=theme.CARD)
        t.pack(fill="x", padx=10, pady=4)
        t.insert("1.0", "\n".join(lines))
        t.configure(state="disabled")

        ctk.CTkLabel(self, text="Measured runtime (same input for every algorithm)",
                     font=(theme.FONT, 14, "bold"), text_color=theme.ACCENT).pack(anchor="w", padx=10, pady=(8, 0))
        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x", padx=10)
        self.n_label = ctk.CTkLabel(bar, text="n = 500", width=80)
        self.n_label.pack(side="left")
        self.n_slider = ctk.CTkSlider(bar, from_=10, to=2000, number_of_steps=199, width=220,
                                      command=lambda v: self.n_label.configure(text=f"n = {int(v)}"))
        self.n_slider.set(500)
        self.n_slider.pack(side="left", padx=6)
        self.kind = ctk.CTkOptionMenu(bar, values=["Random", "Already sorted", "Reverse sorted", "Many duplicates"],
                                      width=150)
        self.kind.pack(side="left", padx=6)
        self.run_btn = ctk.CTkButton(bar, text="Run Benchmark", command=self.run)
        self.run_btn.pack(side="left", padx=6)

        self.out = ctk.CTkTextbox(self, height=230, font=(theme.MONO, 13), fg_color=theme.CARD)
        self.out.pack(fill="both", expand=True, padx=10, pady=6)
        self.out.insert("1.0", "Press 'Run Benchmark'.")
        self.out.configure(state="disabled")

    def _write(self, text):
        self.out.configure(state="normal")
        self.out.delete("1.0", "end")
        self.out.insert("1.0", text)
        self.out.configure(state="disabled")

    def run(self):
        import random
        n, kind = int(self.n_slider.get()), self.kind.get()
        if kind == "Random":
            data = [random.randint(-10000, 10000) for _ in range(n)]
        elif kind == "Already sorted":
            data = list(range(n))
        elif kind == "Reverse sorted":
            data = list(range(n, 0, -1))
        else:
            data = [random.randint(0, 9) for _ in range(n)]
        self.run_btn.configure(state="disabled")
        self._write("Running... (the window stays responsive)")
        self._result = None

        def work():                      # background thread: pure computation, no GUI calls
            self._result = benchmark(data, repeats=3)

        threading.Thread(target=work, daemon=True).start()
        self._info = (n, kind)
        self.after(100, self._poll)

    def _poll(self):                     # GUI update stays on the main thread
        if self._result is None:
            self.after(100, self._poll)
            return
        n, kind = self._info
        rows = sorted(self._result, key=lambda r: r[1])
        text = [f"Input: {kind}, n = {n}   (median of 3 runs, milliseconds)", "",
                f"{'Rank':<6}{'Algorithm':<18}{'Time (ms)':>12}   Correct"]
        for rank, (name, ms, ok) in enumerate(rows, 1):
            text.append(f"{rank:<6}{name:<18}{ms:>12.3f}   {'yes' if ok else 'NO'}")
        text += ["", "Timings depend on your CPU, Python version and background load; they will differ",
                 "between runs and machines. Python-level timings show trends, not exact constants."]
        self._write("\n".join(text))
        self.run_btn.configure(state="normal")


# ================================================================ Window
class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Heap Sort Visualizer - Interactive Sorting Algorithm Learning System")
        self.geometry("1280x780")
        self.minsize(1100, 680)
        self.configure(fg_color=theme.BG)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        side = ctk.CTkFrame(self, width=190, fg_color=theme.PANEL, corner_radius=0)
        side.grid(row=0, column=0, sticky="ns")
        side.grid_propagate(False)
        ctk.CTkLabel(side, text="HEAP SORT", font=(theme.FONT, 20, "bold"), text_color=theme.ACCENT).pack(
            pady=(24, 0))
        ctk.CTkLabel(side, text="Visualizer", font=(theme.FONT, 13), text_color=theme.MUTED).pack(pady=(0, 20))

        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.grid(row=0, column=1, sticky="nsew", padx=14, pady=14)
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(0, weight=1)

        self.pages, self.nav = {}, {}
        factories = [("Dashboard", lambda p: DashboardPage(p, lambda: self.show("Visualizer"))),
                     ("Visualizer", VisualizerPage), ("Learn", LearnPage), ("Compare", ComparePage)]
        for name, make in factories:
            page = make(self.content)
            page.grid(row=0, column=0, sticky="nsew")
            self.pages[name] = page
            btn = ctk.CTkButton(side, text=name, anchor="w", height=40, fg_color="transparent",
                                hover_color=theme.CARD, font=(theme.FONT, 14),
                                command=lambda n=name: self.show(n))
            btn.pack(fill="x", padx=10, pady=2)
            self.nav[name] = btn
        self.show("Dashboard")

    def show(self, name: str):
        self.pages[name].tkraise()
        for n, b in self.nav.items():
            b.configure(fg_color=theme.ACCENT if n == name else "transparent")
