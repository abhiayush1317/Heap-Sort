"""Canvas views: vertical bars and binary tree. They only DRAW a recorded Step."""
import math
import tkinter as tk

from gui import theme


def node_color(i: int, step) -> str:
    if step.swapped and i in step.swapped:
        return theme.C_SWAP
    if i >= step.heap_size:
        return theme.C_SORTED
    if i == step.parent:
        return theme.C_PARENT
    if i == step.left:
        return theme.C_LEFT
    if i == step.right:
        return theme.C_RIGHT
    if i == 0:
        return theme.C_ROOT
    return theme.C_UNSORTED


class _BaseView(tk.Canvas):
    def __init__(self, master, title: str, **kw):
        super().__init__(master, bg=theme.CANVAS_BG, highlightthickness=0, **kw)
        self.title, self.step = title, None
        self.bind("<Configure>", lambda _e: self.redraw())

    def draw(self, step) -> None:
        self.step = step
        self.redraw()

    def redraw(self) -> None:
        self.delete("all")
        self.create_text(10, 10, text=self.title, anchor="nw", fill=theme.MUTED,
                         font=(theme.FONT, 10, "bold"))
        if self.step is not None and len(self.step.array) > 0:
            self._render(self.step, self.winfo_width(), self.winfo_height())

    def _render(self, step, w, h):
        raise NotImplementedError


class BarView(_BaseView):
    def __init__(self, master, **kw):
        super().__init__(master, "ARRAY (bars)", **kw)

    def _render(self, step, w, h):
        arr, n = step.array, len(step.array)
        lo, hi = min(0, min(arr)), max(0, max(arr))
        if hi == lo:
            hi = lo + 1
        top, bottom, margin = 40, h - 24, 16
        scale = (bottom - top) / (hi - lo)
        zero_y = bottom - (0 - lo) * scale
        bw = (w - 2 * margin) / n
        for i, v in enumerate(arr):
            x0, x1 = margin + i * bw + 2, margin + (i + 1) * bw - 2
            y = bottom - (v - lo) * scale
            y0, y1 = min(y, zero_y), max(y, zero_y)
            if y1 - y0 < 2:
                y1 = y0 + 2
            self.create_rectangle(x0, y0, x1, y1, fill=node_color(i, step), outline="")
            if bw >= 22:
                ty = y0 - 8 if v >= 0 else y1 + 8
                self.create_text((x0 + x1) / 2, ty, text=f"{v:g}" if isinstance(v, float) else str(v),
                                 fill=theme.TEXT, font=(theme.FONT, 9))
            if bw >= 16:
                self.create_text((x0 + x1) / 2, h - 10, text=str(i), fill=theme.MUTED, font=(theme.FONT, 8))
        if lo < 0:
            self.create_line(margin, zero_y, w - margin, zero_y, fill="#394456")


class TreeView(_BaseView):
    def __init__(self, master, **kw):
        super().__init__(master, "BINARY TREE (heap view)", **kw)

    def _render(self, step, w, h):
        arr, n = step.array, len(step.array)
        levels = int(math.log2(n)) + 1
        level_h = (h - 50) / levels

        def pos(i):
            lvl = int(math.log2(i + 1))
            idx = i - (2 ** lvl - 1)
            return w * (idx + 0.5) / 2 ** lvl, 40 + level_h * (lvl + 0.5)

        r = max(8, min(20, w / 2 ** (levels - 1) / 2.4, level_h / 2.3))
        for i in range(1, min(n, step.heap_size)):          # edges only inside the active heap
            x0, y0 = pos((i - 1) // 2)
            x1, y1 = pos(i)
            self.create_line(x0, y0, x1, y1, fill="#4b5668", width=2)
        for i, v in enumerate(arr):
            x, y = pos(i)
            self.create_oval(x - r, y - r, x + r, y + r, fill=node_color(i, step), outline="#0b0f14", width=2)
            txt = f"{v:g}" if isinstance(v, float) else str(v)
            self.create_text(x, y, text=txt, fill="#0b0f14", font=(theme.FONT, 9 if r < 15 else 10, "bold"))
            if r >= 14:
                self.create_text(x, y + r + 7, text=str(i), fill=theme.MUTED, font=(theme.FONT, 8))
