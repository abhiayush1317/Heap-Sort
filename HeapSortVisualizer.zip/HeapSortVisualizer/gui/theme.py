"""Colors and fonts shared by all GUI modules."""
BG = "#0f1419"
PANEL = "#171d26"
CARD = "#1e2632"
CANVAS_BG = "#121821"
TEXT = "#e6edf3"
MUTED = "#8b98a9"
ACCENT = "#3b82f6"
ERROR = "#f87171"

C_UNSORTED = "#3b82f6"   # blue    - unsorted / inside heap
C_ROOT = "#facc15"       # yellow  - root
C_PARENT = "#fb923c"     # orange  - parent being heapified
C_LEFT = "#22d3ee"       # cyan    - left child
C_RIGHT = "#c084fc"      # purple  - right child
C_SWAP = "#ef4444"       # red     - elements being swapped
C_SORTED = "#22c55e"     # green   - sorted region

LEGEND = [("Unsorted", C_UNSORTED), ("Root", C_ROOT), ("Parent", C_PARENT),
          ("Left child", C_LEFT), ("Right child", C_RIGHT),
          ("Swapping", C_SWAP), ("Sorted", C_SORTED)]

FONT = "Segoe UI"
MONO = "Consolas"
