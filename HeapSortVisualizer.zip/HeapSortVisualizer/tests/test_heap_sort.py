import os
import random
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from algorithms.comparison import ALGORITHMS, benchmark
from algorithms.heap_sort import (HeapSorter, analyze, get_left_child_index,
                                  get_parent_index, get_right_child_index)
from utils.helpers import MAX_ELEMENTS, parse_input, random_array


def is_max_heap(a, n):
    return all(a[(i - 1) // 2] >= a[i] for i in range(1, n))


class TestHeapSort(unittest.TestCase):
    def check(self, data):
        original = list(data)
        out = HeapSorter(data, record=False).heap_sort()
        self.assertEqual(out, sorted(original))
        self.assertEqual(data, original)            # input list is not mutated

    def test_empty(self):          self.check([])
    def test_one(self):            self.check([7])
    def test_two(self):            self.check([9, 3])
    def test_duplicates(self):     self.check([4, 4, 1, 4, 1, 1, 9, 9])
    def test_all_equal(self):      self.check([5] * 10)
    def test_negatives(self):      self.check([-5, 3, -1, 0, -20, 8])
    def test_floats(self):         self.check([2.5, -1.5, 2.25, 0.0])
    def test_already_sorted(self): self.check(list(range(15)))
    def test_reverse_sorted(self): self.check(list(range(15, 0, -1)))

    def test_random(self):
        for _ in range(200):
            self.check([random.randint(-50, 50) for _ in range(random.randint(0, 31))])

    def test_index_formulas(self):
        self.assertEqual(get_parent_index(1), 0)
        self.assertEqual(get_parent_index(2), 0)
        self.assertEqual(get_parent_index(5), 2)
        self.assertEqual(get_left_child_index(2), 5)
        self.assertEqual(get_right_child_index(2), 6)

    def test_counters(self):
        r = analyze([5, 1, 4, 2, 3])
        self.assertGreater(r.comparisons, 0)
        self.assertGreater(r.swaps, 0)
        self.assertEqual(r.steps[-1].comparisons, r.comparisons)
        self.assertEqual(r.steps[-1].swaps, r.swaps)
        self.assertEqual(analyze([]).comparisons, 0)
        self.assertEqual(analyze([1]).swaps, 0)

    def test_recording_does_not_change_counts(self):
        data = [random.randint(0, 99) for _ in range(25)]
        a, b = HeapSorter(data, True), HeapSorter(data, False)
        a.heap_sort(); b.heap_sort()
        self.assertEqual((a.comparisons, a.swaps), (b.comparisons, b.swaps))

    def test_steps_consistent(self):
        data = [random.randint(-9, 9) for _ in range(20)]
        r = analyze(data)
        self.assertEqual(r.steps[0].phase, "init")
        self.assertEqual(r.steps[0].array, tuple(data))
        self.assertEqual(r.steps[-1].phase, "done")
        self.assertEqual(list(r.steps[-1].array), sorted(data))
        build_done = next(s for s in r.steps if s.phase == "build_done")
        self.assertTrue(is_max_heap(build_done.array, len(data)))
        for s in r.steps:                       # sorted tail never changes after being fixed
            tail = s.array[s.heap_size:]
            self.assertEqual(list(tail), sorted(data)[len(data) - len(tail):] if tail else [])
        for i, s in enumerate(r.steps):
            self.assertEqual(s.number, i)

    def test_empty_and_single_steps(self):
        self.assertEqual(analyze([]).steps[-1].phase, "done")
        self.assertEqual(list(analyze([3]).steps[-1].array), [3])


class TestInput(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(parse_input("5, -3 ,2,2"), [5, -3, 2, 2])
        self.assertEqual(parse_input("1.5, 2"), [1.5, 2])

    def test_invalid(self):
        for bad in ["", "   ", "a, 2", "1,,2", "1,2,", "nan", "inf", ",", "1;2"]:
            with self.assertRaises(ValueError, msg=bad):
                parse_input(bad)

    def test_limit(self):
        with self.assertRaises(ValueError):
            parse_input(",".join(["1"] * (MAX_ELEMENTS + 1)))
        self.assertEqual(len(parse_input(",".join(["1"] * MAX_ELEMENTS))), MAX_ELEMENTS)

    def test_random_array(self):
        self.assertEqual(len(random_array(10)), 10)
        for bad in (0, MAX_ELEMENTS + 1):
            with self.assertRaises(ValueError):
                random_array(bad)


class TestComparison(unittest.TestCase):
    def test_all_algorithms(self):
        for name, fn in ALGORITHMS.items():
            for data in ([], [1], [3, 1, 2], [2] * 8, list(range(30, 0, -1)),
                         [random.randint(-99, 99) for _ in range(300)]):
                self.assertEqual(fn(list(data)), sorted(data), name)

    def test_benchmark(self):
        rows = benchmark([random.randint(0, 99) for _ in range(200)], repeats=1)
        self.assertEqual(len(rows), 6)
        self.assertTrue(all(ok for _, _, ok in rows))


if __name__ == "__main__":
    unittest.main()
