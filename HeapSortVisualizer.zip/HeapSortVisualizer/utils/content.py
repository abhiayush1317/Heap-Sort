"""Educational text for the DSA Learning screen."""
LEARN_TOPICS = [
    ("What is a Binary Heap?",
     "A binary heap is a complete binary tree that satisfies the heap property. It is usually stored "
     "in a plain array, so no pointers are needed. Heaps power priority queues and Heap Sort."),
    ("What is a Complete Binary Tree?",
     "A binary tree in which every level is completely filled except possibly the last, and the last "
     "level is filled from left to right. This shape is exactly what lets us store the tree in an array "
     "with no gaps."),
    ("What is a Max Heap?",
     "A heap where every parent is greater than or equal to its children. Therefore the largest "
     "element is always at the root (index 0). (A Min Heap is the opposite.)"),
    ("Array representation & index formulas (0-indexed)",
     "Node at index i:\n"
     "   Parent       = (i - 1) // 2\n"
     "   Left child   = 2*i + 1\n"
     "   Right child  = 2*i + 2\n"
     "Example: array [90, 50, 70, 10, 20] -> 90 is the root, 50 and 70 are its children, "
     "10 and 20 are the children of 50. Last non-leaf node = n//2 - 1."),
    ("What is Heapify?",
     "Heapify (sift-down) fixes one node: compare the node with its left and right children, swap it "
     "with the larger child if that child is bigger, and repeat down the tree until the node is not "
     "smaller than its children. It assumes both subtrees are already Max Heaps. Cost: O(log n)."),
    ("Building a Max Heap",
     "Start from the last non-leaf node (n//2 - 1) and call heapify on every node moving back to the "
     "root (index 0). Leaves are already valid heaps. This bottom-up construction takes O(n) time."),
    ("How Heap Sort works",
     "1. Build a Max Heap from the array.\n"
     "2. Swap the root (maximum) with the last element of the heap.\n"
     "3. Reduce the heap size by 1 - the last position is now sorted and fixed.\n"
     "4. Heapify the root to restore the Max Heap.\n"
     "5. Repeat steps 2-4 until the heap size is 1. The array is now sorted ascending."),
    ("Why a Max Heap for ascending order?",
     "The Max Heap always gives us the largest remaining element at the root. Placing it at the end of "
     "the array, then the next largest just before it, and so on, fills the array from right to left "
     "with increasing values - which means ascending order, in place. (A Min Heap would produce "
     "descending order with the same in-place technique.)"),
    ("Time and space complexity",
     "Best case:    O(n log n)\n"
     "Average case: O(n log n)\n"
     "Worst case:   O(n log n)\n"
     "Auxiliary space: O(1) - sorting is done in place.\n"
     "Heap Sort is NOT stable (equal elements may change relative order).\n\n"
     "Note: the animation stores a snapshot of the array for every step so you can pause and step "
     "backward. That history needs extra memory, but it belongs to the visualizer, not to the "
     "algorithm - the algorithm itself still uses O(1) auxiliary space.\n\n"
     "Execution time is measured with a real, non-animated run. It varies between runs and machines "
     "(CPU, background load, Python version), so use comparisons and swaps for exact analysis."),
]
