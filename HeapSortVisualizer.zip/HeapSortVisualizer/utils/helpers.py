"""Input parsing / validation and random array generation."""
import math
import random
from typing import List

MAX_ELEMENTS = 31   # 5 tree levels keep the binary-tree drawing readable


def parse_input(text: str) -> List:
    """Convert '5, 3, -2, 8.5' to a list of numbers. Raises ValueError with a clear message."""
    if text is None or not text.strip():
        raise ValueError("Input is empty. Enter numbers separated by commas, e.g. 45, 12, 78, 3")
    result = []
    for pos, raw in enumerate(text.split(","), start=1):
        token = raw.strip()
        if token == "":
            raise ValueError(f"Entry #{pos} is empty (check for double or trailing commas).")
        try:
            value = float(token)
        except ValueError:
            raise ValueError(f"'{token}' (entry #{pos}) is not a valid number.") from None
        if math.isnan(value) or math.isinf(value):
            raise ValueError(f"'{token}' (entry #{pos}) is not a finite number.")
        is_int_text = all(c in "+-0123456789" for c in token)
        result.append(int(value) if is_int_text else value)
    if len(result) > MAX_ELEMENTS:
        raise ValueError(f"Too many elements ({len(result)}). Maximum is {MAX_ELEMENTS}.")
    return result


def random_array(size: int, low: int = -20, high: int = 99) -> List[int]:
    if not 1 <= size <= MAX_ELEMENTS:
        raise ValueError(f"Size must be between 1 and {MAX_ELEMENTS}.")
    return [random.randint(low, high) for _ in range(size)]


def format_array(arr) -> str:
    return "[" + ", ".join(str(x) for x in arr) + "]"
