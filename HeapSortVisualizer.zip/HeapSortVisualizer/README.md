# Heap Sort Visualizer - Interactive Sorting Algorithm Learning System

A desktop DSA project (Python 3 + CustomTkinter) that animates Heap Sort as vertical bars **and** as a
binary tree, with step-by-step controls, live statistics, a learning section and an algorithm comparison tool.

## Run on Windows 10/11 (VS Code)
1. Install Python 3.9+ from python.org (tick "Add Python to PATH"; keep the default "tcl/tk" option).
2. Open the `HeapSortVisualizer` folder in VS Code, open a terminal (Ctrl+`).
3. Create an environment and install the requirement:
   ```
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   ```
4. Start the app: `python main.py`
5. Run the tests: `python -m unittest discover -s tests -v`

## Features
| Area | What you get |
|---|---|
| Input | Custom comma-separated numbers, random generator, size slider (1-31), validation with clear messages |
| Visualization | Bars + binary tree, colors for root / parent / left / right / swapping / sorted / unsorted |
| Controls | Start, Pause, Resume, Reset, New Array, Step Forward, Step Backward, Speed slider |
| Heap build | Heapify comparisons and swaps shown one by one, "Heap ready" frame after the Max Heap is built |
| Extraction | Root swapped with last heap element, heap size shrinks, sorted region turns green |
| Info panel | Operation, step, comparisons, swaps, heap size, original / current / final array, execution time |
| Learn | Binary heap, complete tree, Max Heap, heapify, index formulas, why Max Heap, complexity |
| Compare | Theory table + measured runtime of 6 algorithms on the **same** input |

## Project structure
```
main.py                    entry point
algorithms/heap_sort.py    manual Heap Sort + step recorder
algorithms/comparison.py   other sorts + benchmark
gui/main_window.py         sidebar and the four pages
gui/visualization.py       canvas drawing of bars and tree
gui/components.py          tooltip, stat card, legend
gui/theme.py               colors / fonts
utils/helpers.py           input validation, random array
utils/content.py           learning text
tests/test_heap_sort.py    unit tests
```

## How it works (important for viva)
* **Index formulas (0-indexed):** parent `(i-1)//2`, left `2i+1`, right `2i+2`.
* **Core algorithm:** `build_max_heap()`, `heapify()`, `heap_sort()`, `swap()` in `HeapSorter`. No built-in
  sort is used. Comparisons are counted in `heapify` (child vs. current largest); swaps in `swap()`.
* **Visualization-only part:** with `record=True` the sorter stores a snapshot (`Step`) after each operation.
  The GUI never changes the algorithm; it only replays these snapshots with Tkinter `after()`, so the window
  never freezes and Pause / Step Back are exact.
* **Complexity:** time O(n log n) best / average / worst. Auxiliary space O(1) (in place). The stored step
  history costs extra memory O(n x steps), but that belongs to the visualizer, not to the algorithm.
* **Execution time:** measured on a separate non-recording run, so animation overhead is excluded. It varies
  between runs and machines. Comparisons and swaps are the reliable, repeatable measures.
* **Heap Sort is not stable** (equal values may change relative order).
* **Compare page:** the benchmark runs in a background thread (computation only); results are drawn on the
  main thread. Python-level timings show trends, not exact constants.

## Limits
* Maximum 31 elements so the 5-level tree stays readable.
* Edge cases handled: empty input (error message), one element, duplicates, negatives, decimals, sorted input.
