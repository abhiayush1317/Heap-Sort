"""Heap Sort (Max Heap, ascending order) implemented manually.

The CORE algorithm only uses: build_max_heap, heapify, heap_sort, swap and the
three index helpers.  Counters (comparisons / swaps) are updated by the core
operations themselves.

VISUALIZATION-ONLY work (not part of the algorithm): when ``record=True`` the
sorter also stores an immutable snapshot (``Step``) after each operation.  This
history lets the GUI animate, pause and step backward.  Its memory usage is
O(n * number_of_steps) and is separate from the algorithm's O(1) auxiliary space.
"""
from dataclasses import dataclass
from time import perf_counter
from typing import List, Optional, Sequence, Tuple


# ---------------------------------------------------------------- index helpers
def get_parent_index(i: int) -> int:
    return (i - 1) // 2


def get_left_child_index(i: int) -> int:
    return 2 * i + 1


def get_right_child_index(i: int) -> int:
    return 2 * i + 2


# ------------------------------------------------------------------- snapshot
@dataclass(frozen=True)
class Step:
    """One recorded frame of the animation (visualization-only data)."""
    number: int
    phase: str                  # init | build | build_done | extract | done
    message: str
    array: Tuple
    heap_size: int
    comparisons: int
    swaps: int
    parent: Optional[int] = None
    left: Optional[int] = None
    right: Optional[int] = None
    swapped: Optional[Tuple[int, int]] = None


@dataclass
class SortResult:
    original: List
    sorted_array: List
    steps: List[Step]
    comparisons: int
    swaps: int
    time_ms: float              # measured on a separate non-recording run


# --------------------------------------------------------------------- sorter
class HeapSorter:
    def __init__(self, data: Sequence, record: bool = True):
        self.original = list(data)
        self.arr = list(data)
        self.n = len(self.arr)
        self.heap_size = self.n
        self.comparisons = 0
        self.swaps = 0
        self.record = record
        self.steps: List[Step] = []
        self._phase = "init"

    # index helpers exposed as methods too
    get_parent_index = staticmethod(get_parent_index)
    get_left_child_index = staticmethod(get_left_child_index)
    get_right_child_index = staticmethod(get_right_child_index)

    # visualization-only
    def _log(self, phase, message, parent=None, left=None, right=None, swapped=None):
        if not self.record:
            return
        self.steps.append(Step(len(self.steps), phase, message, tuple(self.arr),
                               self.heap_size, self.comparisons, self.swaps,
                               parent, left, right, swapped))

    # core operations
    def swap(self, i: int, j: int) -> None:
        self.arr[i], self.arr[j] = self.arr[j], self.arr[i]
        self.swaps += 1
        self._log(self._phase,
                  f"Swap index {i} and {j}  ->  values are now "
                  f"{self.arr[i]} (index {i}) and {self.arr[j]} (index {j})",
                  swapped=(i, j))

    def heapify(self, n: int, i: int) -> None:
        """Sift node i down so the subtree rooted at i is a Max Heap (heap size n)."""
        while True:
            largest = i
            left, right = get_left_child_index(i), get_right_child_index(i)
            lv = left if left < n else None
            rv = right if right < n else None
            self._log(self._phase,
                      f"Heapify node {i} (value {self.arr[i]}): compare it with its children",
                      parent=i, left=lv, right=rv)
            if lv is not None:
                self.comparisons += 1
                bigger = self.arr[left] > self.arr[largest]
                self._log(self._phase,
                          f"Compare left child {self.arr[left]} > parent {self.arr[largest]}? "
                          f"{'Yes' if bigger else 'No'}",
                          parent=i, left=lv, right=rv)
                if bigger:
                    largest = left
            if rv is not None:
                self.comparisons += 1
                bigger = self.arr[right] > self.arr[largest]
                self._log(self._phase,
                          f"Compare right child {self.arr[right]} > current largest {self.arr[largest]}? "
                          f"{'Yes' if bigger else 'No'}",
                          parent=i, left=lv, right=rv)
                if bigger:
                    largest = right
            if largest == i:
                return
            self.swap(i, largest)
            i = largest

    def build_max_heap(self) -> None:
        self._phase = "build"
        n = self.n
        for i in range(n // 2 - 1, -1, -1):
            self.heapify(n, i)
        self._log("build_done", "Max Heap built: every parent >= its children. Root is the maximum.")

    def heap_sort(self) -> List:
        self.heap_size = self.n
        self._log("init", "Initial (unsorted) array")
        self.build_max_heap()
        self._phase = "extract"
        for end in range(self.n - 1, 0, -1):
            self.swap(0, end)                       # move max to its final place
            self.heap_size = end                    # shrink the heap
            self._log("extract",
                      f"Extracted max {self.arr[end]} -> sorted position {end}. Heap size = {end}")
            self.heapify(end, 0)                    # restore Max Heap property
        self.heap_size = 0
        self._log("done", "Array is sorted in ascending order")
        return self.arr


def analyze(data: Sequence) -> SortResult:
    """Run once with recording (for animation) and once without (for timing)."""
    rec = HeapSorter(data, record=True)
    rec.heap_sort()
    fast = HeapSorter(data, record=False)
    t0 = perf_counter()
    fast.heap_sort()
    ms = (perf_counter() - t0) * 1000
    return SortResult(list(data), rec.arr, rec.steps, rec.comparisons, rec.swaps, ms)
