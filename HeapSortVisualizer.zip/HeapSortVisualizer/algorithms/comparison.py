"""Other sorting algorithms + benchmark helper for the comparison screen."""
from statistics import median
from time import perf_counter
from typing import Callable, Dict, List

from algorithms.heap_sort import HeapSorter

COMPLEXITY = [  # name, best, average, worst, auxiliary space
    ("Bubble Sort",    "O(n)",       "O(n^2)",     "O(n^2)",     "O(1)"),
    ("Selection Sort", "O(n^2)",     "O(n^2)",     "O(n^2)",     "O(1)"),
    ("Insertion Sort", "O(n)",       "O(n^2)",     "O(n^2)",     "O(1)"),
    ("Merge Sort",     "O(n log n)", "O(n log n)", "O(n log n)", "O(n)"),
    ("Quick Sort",     "O(n log n)", "O(n log n)", "O(n^2)",     "O(log n)"),
    ("Heap Sort",      "O(n log n)", "O(n log n)", "O(n log n)", "O(1)"),
]


def bubble_sort(a: List) -> List:
    n = len(a)
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                swapped = True
        if not swapped:
            break
    return a


def selection_sort(a: List) -> List:
    n = len(a)
    for i in range(n - 1):
        m = i
        for j in range(i + 1, n):
            if a[j] < a[m]:
                m = j
        a[i], a[m] = a[m], a[i]
    return a


def insertion_sort(a: List) -> List:
    for i in range(1, len(a)):
        key, j = a[i], i - 1
        while j >= 0 and a[j] > key:
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = key
    return a


def merge_sort(a: List) -> List:
    if len(a) <= 1:
        return a
    mid = len(a) // 2
    l, r = merge_sort(a[:mid]), merge_sort(a[mid:])
    out, i, j = [], 0, 0
    while i < len(l) and j < len(r):
        if l[i] <= r[j]:
            out.append(l[i]); i += 1
        else:
            out.append(r[j]); j += 1
    out.extend(l[i:]); out.extend(r[j:])
    return out


def quick_sort(a: List) -> List:
    """Hoare partition, middle pivot, explicit stack (no recursion limit issues)."""
    stack = [(0, len(a) - 1)]
    while stack:
        lo, hi = stack.pop()
        while lo < hi:
            pivot, i, j = a[(lo + hi) // 2], lo - 1, hi + 1
            while True:
                i += 1
                while a[i] < pivot: i += 1
                j -= 1
                while a[j] > pivot: j -= 1
                if i >= j:
                    break
                a[i], a[j] = a[j], a[i]
            if j - lo < hi - j:          # continue with smaller part, push larger
                stack.append((j + 1, hi)); hi = j
            else:
                stack.append((lo, j)); lo = j + 1
    return a


def heap_sort(a: List) -> List:
    return HeapSorter(a, record=False).heap_sort()


ALGORITHMS: Dict[str, Callable[[List], List]] = {
    "Bubble Sort": bubble_sort, "Selection Sort": selection_sort,
    "Insertion Sort": insertion_sort, "Merge Sort": merge_sort,
    "Quick Sort": quick_sort, "Heap Sort": heap_sort,
}


def benchmark(data: List, repeats: int = 3):
    """Time every algorithm on a copy of the SAME input. Returns (name, median_ms, correct)."""
    expected = sorted(data)          # used only to verify correctness, not timed
    rows = []
    for name, fn in ALGORITHMS.items():
        times, ok = [], True
        for _ in range(repeats):
            work = list(data)
            t0 = perf_counter()
            result = fn(work)
            times.append((perf_counter() - t0) * 1000)
            ok = ok and result == expected
        rows.append((name, median(times), ok))
    return rows
