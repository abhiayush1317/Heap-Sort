"""Entry point:  python main.py"""
import customtkinter as ctk

from gui.main_window import App


def main() -> None:
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
    App().mainloop()


if __name__ == "__main__":
    main()
